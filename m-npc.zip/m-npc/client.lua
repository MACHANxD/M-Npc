-- Load configuration
local config = Config

-- Convert percentage to a multiplier (0.0 to 1.0)
local populationMultiplier = config.NPCPopulationPercentage / 100.0

-- Function to set NPC population density
function SetNPCPopulationDensity()
    -- Set the density multiplier for pedestrians
    SetPedDensityMultiplierThisFrame(populationMultiplier)

    -- Set the density multiplier for vehicles
    SetVehicleDensityMultiplierThisFrame(populationMultiplier)

    -- Set the density multiplier for parked vehicles
    SetParkedVehicleDensityMultiplierThisFrame(populationMultiplier)

    -- Set the density multiplier for random vehicles
    SetRandomVehicleDensityMultiplierThisFrame(populationMultiplier)

    -- Disable random cops and emergency vehicles if population is 0%
    if config.NPCPopulationPercentage == 0 then
        SetCreateRandomCops(false)
        SetCreateRandomCopsNotOnScenarios(false)
        SetCreateRandomCopsOnScenarios(false)
    else
        SetCreateRandomCops(true)
        SetCreateRandomCopsNotOnScenarios(true)
        SetCreateRandomCopsOnScenarios(true)
    end
end

-- Main loop to continuously adjust NPC population
CreateThread(function()
    while true do
        SetNPCPopulationDensity()
        Wait(0) -- Run every frame
    end
end)