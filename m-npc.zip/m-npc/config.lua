Config = {}

-- Set the NPC population density percentage (0 to 100)
Config.NPCPopulationPercentage = 50 -- Default to 50%