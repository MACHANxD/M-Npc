fx_version 'cerulean'
game 'gta5'

author 'YourName'
description 'Control NPC population density in FiveM'
version '1.0.0'

client_scripts {
    'config.lua',
    'client.lua'
}